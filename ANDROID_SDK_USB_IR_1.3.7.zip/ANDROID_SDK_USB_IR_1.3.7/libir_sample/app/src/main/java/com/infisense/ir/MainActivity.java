package com.infisense.ir;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * @Description:    root project
 * @Author:         brilliantzhao
 * @CreateDate:     3/18/2023 9:21 AM
 * @UpdateUser:
 * @UpdateDate:     3/18/2023 9:21 AM
 * @UpdateRemark:
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

}