//
//  
//  INFIP2Demo
//
//
//

#import "CZHomeViewController.h"
#import <INFIP2SDK/INFIP2SDK.h>
#import "CZPageView.h"
#import "CZMeasureSelectView.h"
#import "Masonry.h"
#import "CZSetBCView.h"
#import "CZPresentView.h"
#import "MBProgressHUD.h"

static int frameCount = 0;

@interface CZHomeViewController ()<IFISPImageHandleInterface,CZPageViewDelegate,CZCanvasSelectViewDelegate>

@property (nonatomic , strong) IFSubChainView *cameraView;//预览View
@property (nonatomic , strong) NSArray *pseudoNames;//伪彩名

@property (nonatomic , strong) CZPageView *pseudoSelectView;
@property (nonatomic , strong) CZPresentView *presentView;
@property (nonatomic , strong) CZMeasureSelectView *measureTempView;

@property (nonatomic , strong) IFCanvas *canvas;//点线框管理类
@property (nonatomic , strong) NSData *solvedTempData;//保存的处理后的温度数据
@property (nonatomic , strong) IFSubChainView *containerView;//UI全部包裹在此View中
@property (nonatomic , strong) CZSetBCView *bcSetView;//UI全部包裹在此View中

@property (nonatomic , strong) UIButton *emButton;//发射率
@property (nonatomic , strong) UIButton *tauButton;//环境温度
@property (nonatomic , strong) UIButton *distButton;//目标距离

@property (nonatomic , strong) UIButton *lowTempSettingButton;//二次标定低温值设置
@property (nonatomic , strong) UIButton *highTempSettingButton;//二次标定高温值设置

@property (nonatomic , strong) NSString *lowTemp;
@property (nonatomic , strong) NSString *highTemp;

@property (nonatomic , strong) UIButton *calibrationStartingButton;
@property bool needCaculation;
@property bool calOpen;

@property (nonatomic , strong) UIButton *rotationButton;//旋转设置
@property (nonatomic , strong) UIButton *mirrorButton;//旋转设置

@end

@implementation CZHomeViewController
{
    int _imageHeight;
    int _imageWidth;
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    if (self.view.window.safeAreaInsets.top <= 20) {
        CGRect r = _measureTempView.frame;
        r.origin.y = CGRectGetMaxY(self.cameraView.frame) - 40;
        _measureTempView.frame = r;
    }
}

/*
 ##特别注意:
 温度较温
 - 1、模组第一次插入，画面显示出来iOS 时间可能会长一点，大约2到3秒多，因为第一次，是有一个读取模组flash 的时长，第二次使用就不会了。

 - 2、每一次进入画面，温度数据是不准的，这个时候我们就会进行打快门较温。 这里特别注意打快门的次数，因为打一次快门温度是不会准的。

 可以按照以下节奏打：
 倒记时20秒： 19秒 打一次快门 ------> 16秒打一次快门---------->13秒打一次快门------->8秒打一次快门------->5秒打一次快门

 打快门的时机，是在代理回调有数据后，再进行打快门 和一些参数设置操作。

 退出画面注意：请调用删除代理、 调用一下停图，只有停图成功后在返回上一页。
 
 */


- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"----version:%@",IFClient.client.version);

    [self.navigationController.navigationBar setTranslucent:NO];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self.navigationController.navigationBar setBarTintColor:UIColor.blackColor];
    UIBarButtonItem *shutterItem = [[UIBarButtonItem alloc] initWithTitle:@"快门" style:UIBarButtonItemStylePlain target:self action:@selector(actionForShutter)];
    shutterItem.tintColor = UIColor.whiteColor;
    UIBarButtonItem *pseudoItem = [[UIBarButtonItem alloc] initWithTitle:@"伪彩" style:UIBarButtonItemStylePlain target:self action:@selector(actionForSwitchPseudo)];
    pseudoItem.tintColor = UIColor.whiteColor;
    UIBarButtonItem *resetItem = [[UIBarButtonItem alloc] initWithTitle:@"Reset" style:UIBarButtonItemStylePlain target:self action:@selector(actionForReset)];
    resetItem.tintColor = UIColor.whiteColor;
    UIBarButtonItem *bcItem = [[UIBarButtonItem alloc] initWithTitle:@"BC" style:UIBarButtonItemStylePlain target:self action:@selector(actionForSetBC)];
    bcItem.tintColor = UIColor.whiteColor;
    UIBarButtonItem *calItem = [[UIBarButtonItem alloc] initWithTitle:@"cal" style:UIBarButtonItemStylePlain target:self action:@selector(actionForCal)];
    calItem.tintColor = UIColor.whiteColor;
    UIBarButtonItem *gainItem = [[UIBarButtonItem alloc] initWithTitle:@"增益切换" style:UIBarButtonItemStylePlain target:self action:@selector(actionForGainSwitch)];
    gainItem.tintColor = UIColor.whiteColor;
    
    self.navigationItem.leftBarButtonItems = @[pseudoItem , bcItem ,resetItem,gainItem,calItem];
    
    self.navigationItem.rightBarButtonItem = shutterItem;
    
    //SDK 配置初始化
    
    IFClientConfiger *config = [IFClientConfiger new];
    config.protocolString = @"com.topdon.tios1";
    
    _imageWidth = 192;
    _imageHeight = 256;
    
    [IFClient setConfiger:config];
    
//    BOOL connect = IFClient.isDeviceConnect;
    
    //初始化预览view(放在最底层UI，不要放入containerView中)
    self.cameraView = [[IFSubChainView alloc] init];
    self.cameraView.contentMode = UIViewContentModeScaleAspectFit;
    self.cameraView.userInteractionEnabled = YES;
    self.cameraView.layer.masksToBounds = YES;
    [self.view addSubview:self.cameraView];
    self.cameraView.frame = CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.width * _imageHeight / _imageWidth);
    
    //点线框UI都放入容器中(容器放在最上层)
    self.containerView = [[IFSubChainView alloc] init];
    [self.view addSubview:self.containerView];
    [self.containerView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    //SDK Notification
    [IFClient.client addParamObserver:self];
    //出图开始
    [IFClient.client startStream:^(BOOL success, NSError *error) {
        //返回结果
        if (success) {
            [IFClient.client startShutterPlan];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
#warning 获取SN PN 版本号
                //获取SN PN 版本号
                NSLog(@"SN: %@ PN: %@ version: %@" , IFClient.client.sn,IFClient.client.pn,IFClient.client.version);
//                [self actionForShutter];
            });
        }
    }];

#warning 日志开启
    //日志开启
//    [[IFClient client] enableLogcat];
    
    //伪彩设置
    //    IFClient.client.currentPseudoMode = IFPseudoModeIronBow;
    //旋转
    //    IFClient.client.irRotationType = IFIRRotationTypeOriginal;
    //镜像
    //    IFClient.client.mirrorIR = YES;
    
    
    //初始化伪彩列表
    self.pseudoNames = @[@"白热",@"黑热",@"彩虹",@"铁红",@"极光",@"丛林",@"金红",@"医疗",@"微光",@"辉金",@"红热"];
    if (!self.pseudoSelectView) {
        NSMutableArray *items = [[NSMutableArray alloc] init];
        for (NSUInteger index = 0; index < 11; index++) {
            CZPseudoItem *item = [CZPseudoItem new];
            item.mode = (IFPseudoMode)index;
            item.name = self.pseudoNames[index];
            UIImage *image = [UIImage imageNamed:[@"add" stringByAppendingString:@(index).stringValue]];
            item.image = image;
            [items addObject:item];
        }
        
        self.pseudoSelectView = [[CZPageView alloc] initWithSelectItems:items itemSize:CGSizeMake(55, 55 * _imageHeight / _imageWidth)];
        self.pseudoSelectView.frame = CGRectMake(0, 0, self.view.bounds.size.width, 88);
        self.pseudoSelectView.czDelegate = self;
    }
    
    //点线框测温
    _measureTempView = [[CZMeasureSelectView alloc] initWithSelectItems:[self createMeasureTempItems] frame:CGRectMake(0, CGRectGetMaxY(self.cameraView.frame), self.view.bounds.size.width , 68)];
    _measureTempView.czDelegate = self;
    [self.containerView addSubview:_measureTempView];
    
    self.canvas = [IFCanvas create];
    self.canvas.switchDrawType(IFDrawTypeProfessional);//专业模式可以绘制三个元素 简洁模式一个选素
    [self.canvas setItemsCount:@(13)];
    IFCanvasConfig *configer = [IFCanvasConfig new];
    configer.enableCustomTagName = YES;//默认自定义标签
    configer.contentWidth = self.cameraView.frame.size.width;
    configer.contentHeight = self.cameraView.frame.size.height;
    configer.imageWidth = _imageWidth;
    configer.imageHeight = _imageHeight;
    configer.tempPointRadius = 10;
    configer.labelColor = UIColor.brownColor;
#warning 设置点测温图片
    configer.dotIconImage = [UIImage imageNamed:@"canvas_dot_icon_select"];//设置点测温图片
#warning 客户自定义（不显示测温结果，客户自定义）
    configer.disableMeasureResultView = YES;
    self.canvas.setConfiger(configer);
    self.canvas.addSuperview(self.cameraView);
//    [self.canvas.canvasView layoutResultViews];
    __weak typeof(self) weakSelf = self;
    self.canvas.canvasChanged = ^(BOOL isDrawing) {
        if (!isDrawing) {
            [weakSelf updateConvasView];
        }
    };
    
    //画布点击无效设置
//    self.containerView.enableViewClassNames = @[NSStringFromClass([self.canvas.canvasView class])];
    
    
    //发射率
    self.emButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.emButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.emButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    [self.containerView addSubview:self.emButton];
    [self.emButton addTarget:self action:@selector(actionForEM) forControlEvents:UIControlEventTouchUpInside];
    [self.emButton setTitle:NSLocalizedString(@"发射率", nil) forState:UIControlStateNormal];
    
    //环境温度
    self.tauButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.tauButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    self.tauButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.containerView addSubview:self.tauButton];
    [self.tauButton addTarget:self action:@selector(actionForTA) forControlEvents:UIControlEventTouchUpInside];
    [self.tauButton setTitle:NSLocalizedString(@"环境温度", nil) forState:UIControlStateNormal];
    
    //设置目标距离
    self.distButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.distButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    self.distButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.containerView addSubview:self.distButton];
    [self.distButton addTarget:self action:@selector(actionForDist) forControlEvents:UIControlEventTouchUpInside];
    [self.distButton setTitle:NSLocalizedString(@"目标距离", nil) forState:UIControlStateNormal];
    
    self.rotationButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.rotationButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    self.rotationButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.containerView addSubview:self.rotationButton];
    [self.rotationButton addTarget:self action:@selector(actionForRotate) forControlEvents:UIControlEventTouchUpInside];
    [self.rotationButton setTitle:NSLocalizedString(@"旋转", nil) forState:UIControlStateNormal];
    
    self.mirrorButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.mirrorButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    self.mirrorButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.containerView addSubview:self.mirrorButton];
    [self.mirrorButton addTarget:self action:@selector(actionForMirror) forControlEvents:UIControlEventTouchUpInside];
    [self.mirrorButton setTitle:NSLocalizedString(@"镜像", nil) forState:UIControlStateNormal];
    
    [self.emButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(15);
        make.size.mas_greaterThanOrEqualTo(0);
        make.top.mas_equalTo(self.measureTempView.mas_bottom).offset(0);
    }];
    
    [self.distButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.emButton.mas_right).offset(10);
        make.size.mas_greaterThanOrEqualTo(0);
        make.centerY.mas_equalTo(self.emButton);
    }];
    
    [self.tauButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.distButton.mas_right).offset(10);
        make.size.mas_greaterThanOrEqualTo(0);
        make.centerY.mas_equalTo(self.emButton);
    }];
    
    [self.rotationButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.tauButton.mas_right).offset(10);
        make.size.mas_greaterThanOrEqualTo(0);
        make.centerY.mas_equalTo(self.emButton);
    }];
    
    [self.mirrorButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.rotationButton.mas_right).offset(10);
        make.size.mas_greaterThanOrEqualTo(0);
        make.centerY.mas_equalTo(self.emButton);
    }];
    
    //亮度对比度设置
    self.bcSetView = [[CZSetBCView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 300)];
    self.bcSetView.brightnessChanged = ^(int brightness) {
        [IFClient.client setV_brightness:brightness];
    };
    self.bcSetView.contrastChanged = ^(int contrast) {
        [IFClient.client setV_contrast:contrast];
    };
    
    //    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //        //拍照
    //        UIImage *img = [[self class] convertViewToImage:weakSelf.cameraView scale:1.0];               //截图
    //        [IFClient.client takeShotByImage:img comletion:^(NSString *shotImageFilePath) {
    //
    //        }];
    //    });
    
    //温度二次标定
    
    _lowTemp = @"10";
    _highTemp = @"30";
    self.lowTempSettingButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.lowTempSettingButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.lowTempSettingButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    [self.containerView addSubview:self.lowTempSettingButton];
    [self.lowTempSettingButton addTarget:self action:@selector(actionForSettingLowTemp) forControlEvents:UIControlEventTouchUpInside];
    [self.lowTempSettingButton setTitle:[NSString stringWithFormat:@"%@%@",NSLocalizedString(@"低温设置：", nil) , _lowTemp] forState:UIControlStateNormal];
    [self.lowTempSettingButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_greaterThanOrEqualTo(0);
        make.left.mas_equalTo(self.emButton);
        make.top.mas_equalTo(self.emButton.mas_bottom).offset(2);
    }];
    
    
    self.highTempSettingButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.highTempSettingButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    self.highTempSettingButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.containerView addSubview:self.highTempSettingButton];
    [self.highTempSettingButton addTarget:self action:@selector(actionForSettingHighTemp) forControlEvents:UIControlEventTouchUpInside];
    [self.highTempSettingButton setTitle:[NSString stringWithFormat:@"%@%@",NSLocalizedString(@"高温设置：", nil) , _highTemp] forState:UIControlStateNormal];
    [self.highTempSettingButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_greaterThanOrEqualTo(0);
        make.left.mas_equalTo(self.lowTempSettingButton.mas_right).offset(10);;
        make.top.mas_equalTo(self.emButton.mas_bottom).offset(2);
    }];
    
    self.calibrationStartingButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.calibrationStartingButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    self.calibrationStartingButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.containerView addSubview:self.calibrationStartingButton];
    [self.calibrationStartingButton addTarget:self action:@selector(actionForCalibrationStarting) forControlEvents:UIControlEventTouchUpInside];
    [self.calibrationStartingButton setTitle:NSLocalizedString(@"点击开始低温标定", nil) forState:UIControlStateNormal];
    [self.calibrationStartingButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_greaterThanOrEqualTo(0);
        make.left.mas_equalTo(self.highTempSettingButton.mas_right).offset(10);;
        make.top.mas_equalTo(self.emButton.mas_bottom).offset(2);
    }];
    
    self.lowTempSettingButton.hidden = self.highTempSettingButton.hidden = self.calibrationStartingButton.hidden = YES;
}

-(NSArray *)createMeasureTempItems
{
    NSMutableArray *items = [[NSMutableArray alloc] init];
    
    {
        CZCanvasSelectItem *item = [CZCanvasSelectItem new];
        item.selectType = CZCanvasSelectTypeDot;
        item.title = NSLocalizedString(@"点", nil);
        item.supportedAllOrientation = NO;
        [items addObject:item];
    }
    
    {
        CZCanvasSelectItem *item = [CZCanvasSelectItem new];
        item.selectType = CZCanvasSelectTypeLine;
        item.title = NSLocalizedString(@"线", nil);
        item.supportedAllOrientation = NO;
        [items addObject:item];
    }
    
    {
        CZCanvasSelectItem *item = [CZCanvasSelectItem new];
        item.selectType = CZCanvasSelectTypeRect;
        item.title = NSLocalizedString(@"框", nil);
        item.supportedAllOrientation = NO;
        [items addObject:item];
    }
    
    {
        CZCanvasSelectItem *item = [CZCanvasSelectItem new];
        item.selectType = CZCanvasSelectTypeDelete;
        item.supportedAllOrientation = NO;
        item.title = NSLocalizedString(@"删除", nil);
        [items addObject:item];
    }
    return items;
}

//快门
-(void)actionForShutter
{
    [IFClient.client openShutter:^(BOOL success) {
        //TO DO
    }];
}

#pragma - mark IFISPImageHandleInterface

- (void)didReceiveConnectNotification
{
    //设备连接上后需调用出图接口
    [IFClient.client startStream:^(BOOL success, NSError *error) {
        //TO DO
        if (success) {
            //每次重新出图后调用一次快门接口
            [self actionForShutter];
        }
    }];
}

- (void)didReceiveDisconnectNotification
{
    //设备断开
    //TO DO
}

- (void)didEnterBackgroundNotification
{
    //TO DO
}

- (void)didEnterForegroundNotification
{
    //TO DO
}


- (void)didReceivedSolvedImage:(UIImage *)image originalIRData:(NSData *)originalIRData originalTempData:(NSData *)originalTempData solvedIRData:(NSData *)solvedIRData solvedTempData:(NSData *)solvedTempData
{
    {
        IFTempMeasureResponse *res = [IFClient.client getPointTempWithImagePoint:CGPointMake(50, 50)
                                                                      imageWidth:image.size.width
                                                                     imageHeight:image.size.height
                                                                     imageBuffer:(uint8_t *)originalTempData.bytes];
        NSLog(@"point temp %@c" , res.averageTemp);
    }
    
    {
        IFTempMeasureResponse *res = [IFClient.client
                                      getLineTempWithImageStartPoint:CGPointMake(1, 1)
                                      endPoint:CGPointMake(100, 100)
                                      imageWidth:image.size.width
                                      imageHeight:image.size.height
                                      imageBuffer:(uint8_t *)originalTempData.bytes];
        NSLog(@"line average temp %@c" , res.averageTemp);
        NSLog(@"line max temp %@c" , res.maxTemp);
        NSLog(@"line min temp %@c" , res.minTemp);
        
    }
    
    {
        
        IFTempMeasureResponse *res = [IFClient.client getRectTempWithImageStartPoint:CGPointMake(10, 10)
                                                                            endPoint:CGPointMake(50, 50) 
                                                                          imageWidth:image.size.width
                                                                         imageHeight:image.size.height
                                                                         imageBuffer:(uint8_t *)originalTempData.bytes];
        NSLog(@"rect average temp %@c" , res.averageTemp);
        NSLog(@"rect max temp %@c" , res.maxTemp);
        NSLog(@"rect min temp %@c" , res.minTemp);
        
    }
    
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        weakSelf.solvedTempData = solvedTempData;
        weakSelf.cameraView.image = image;
        //一秒刷新一次
        if (frameCount % 25 == 0) {
            [weakSelf updateConvasView];
        }
        frameCount ++;
        if (frameCount > 100) frameCount = 0;
    });
}

#pragma - mark CZPageViewDelegate

-(void)pageViewDidSelectPseudoMode:(IFPseudoMode)model
{
    //点击后选择
    IFClient.client.currentPseudoMode = model;
}

- (void)pageViewDidEndDeceleratingSelectPseudoMode:(IFPseudoMode)model
{
    //滑动后选择
    //这边可自己定制显示伪彩名
    self.presentView.titleLabel.text = self.pseudoNames[model];
    IFClient.client.currentPseudoMode = model;
}

#pragma - mark

-(void)measureTempViewDidSelectCanvasType:(CZCanvasSelectType)type
{
    if (type == CZCanvasSelectTypeDot) {
        self.canvas.switchShapeType(IFDrawShapeTypePoint);
    }
    else if (type == CZCanvasSelectTypeLine) {
        self.canvas.switchShapeType(IFDrawShapeTypeLine);
    }
    else if (type == CZCanvasSelectTypeRect) {
        self.canvas.switchShapeType(IFDrawShapeTypeRect);
    }
    else if (type == CZCanvasSelectTypeDelete) {
        self.canvas.switchShapeType(IFDrawShapeTypeNone);
        [self.canvas clearAllViews];
    }
}


//////////////private///////////////

//刷新点 线 框 圆
-(void)updateConvasView
{
    for (IFCanvasItemBase *item in self.canvas.items) {
        item.resultMaxTempPre = NSLocalizedString(@"最大：", nil);
        item.resultMinTempPre = NSLocalizedString(@"最小：", nil);
        item.resultAverageTempPre = NSLocalizedString(@"平均：", nil);
        item.resultPointTempPre = NSLocalizedString(@"温度：", nil);
        item.tempUnit = @"度";
        
        IFTempMeasureResponse *res_point = [IFClient.client getRectTempWithImageStartPoint:CGPointMake(1, 1) endPoint:CGPointMake(_imageWidth - 1, _imageHeight-1) imageWidth:_imageWidth imageHeight:_imageHeight imageBuffer:(uint8_t *)self.solvedTempData.bytes]; //获取图片最底最高温
        NSLog(@"maxTemp------>%f-----minTemp---->%f",res_point.maxTemp.floatValue,res_point.minTemp.floatValue);
        
        if ([item isKindOfClass:[IFCanvasItemDot class]]) {
            IFCanvasItemDot *dot = (IFCanvasItemDot *)item;
            IFTempMeasureResponse *res = [IFClient.client getPointTempWithImagePoint:CGPointMake(dot.imagePoint.x, dot.imagePoint.y)
                                                                          imageWidth:_imageWidth
                                                                         imageHeight:_imageHeight
                                                                         imageBuffer:(uint8_t *)self.solvedTempData.bytes];

            dot.pointTemp = res.averageTemp.floatValue;
            NSLog(@"point====>%@" , NSStringFromCGPoint(dot.imagePoint));
            NSLog(@"temp====>%@" , @(dot.pointTemp));
#warning 设置自定义标签
            dot.enableCustomTagName = YES;
            dot.customName = @(dot.pointTemp).stringValue;
            dot.textColor = [UIColor blueColor];
            dot.textFont = [UIFont systemFontOfSize:18];
        }
        else if ([item isKindOfClass:[IFCanvasItemLine class]]) {
            IFCanvasItemLine *line = (IFCanvasItemLine *)item;
            IFCanvasItemDot *minTempDot = [[IFCanvasItemDot alloc] init];
            IFCanvasItemDot *maxTempDot = [[IFCanvasItemDot alloc] init];
            
            line.imageWidth = _imageWidth;
            line.imageHeight = _imageHeight;
            line.contentWidth = self.cameraView.bounds.size.width;
            line.contentHeight = self.cameraView.bounds.size.height;
            
            minTempDot.imageWidth = _imageWidth;
            minTempDot.imageHeight = _imageHeight;
            minTempDot.contentWidth = self.cameraView.bounds.size.width;
            minTempDot.contentHeight = self.cameraView.bounds.size.height;
            
            maxTempDot.imageWidth = _imageWidth;
            maxTempDot.imageHeight = _imageHeight;
            maxTempDot.contentWidth = self.cameraView.bounds.size.width;
            maxTempDot.contentHeight = self.cameraView.bounds.size.height;
            
            minTempDot.mainColor = UIColor.blueColor;
            maxTempDot.mainColor = UIColor.redColor;
            minTempDot.radius = maxTempDot.radius = 10;
            
            UILabel *tagLabel = [item.itemView viewWithTag:100];
            if (!tagLabel)
            {
                tagLabel = [[UILabel alloc] init];
                tagLabel.textColor = UIColor.redColor;
                tagLabel.textAlignment = NSTextAlignmentCenter;
                tagLabel.tag = 100;
                [item.itemView addSubview:tagLabel];
            }
            tagLabel.frame = CGRectMake(0, 0, 100, 100);
            [tagLabel sizeToFit];
            tagLabel.center = CGPointMake(CGRectGetMidX(item.itemView.bounds), CGRectGetMidY(item.itemView.bounds));
            
            IFTempMeasureResponse *res = nil;
            CGPoint startPoint;
            CGPoint endPoint;
            if ([item isMemberOfClass:[IFCanvasItemLine class]]) {
                startPoint = line.lineImageStartPoint;
                endPoint = line.lineImageEndPoint;
                res = [IFClient.client getLineTempWithImageStartPoint:startPoint
                                                             endPoint:endPoint
                                                           imageWidth:_imageWidth
                                                          imageHeight:_imageHeight
                                                          imageBuffer:(uint8_t *)self.solvedTempData.bytes];
                tagLabel.text = [@"L" stringByAppendingFormat:@"%@" , @(item.index+1)];
            }
            else
            {
                startPoint = line.rectImageStartPoint;
                endPoint = line.rectImageEndPoint;
                res = [IFClient.client getRectTempWithImageStartPoint:startPoint
                                                             endPoint:endPoint
                                                           imageWidth:_imageWidth
                                                          imageHeight:_imageHeight
                                                          imageBuffer:(uint8_t *)self.solvedTempData.bytes];
                tagLabel.text = [@"R" stringByAppendingFormat:@"%@" , @(item.index+1)];
            }
            
            line.averageTemp = res.averageTemp.floatValue;
            
            maxTempDot.point = [line imagePointToUIPoint:res.maxCor];
            minTempDot.point = [line imagePointToUIPoint:res.minCor];
            
            maxTempDot.pointTemp = res.maxTemp.floatValue;
            minTempDot.pointTemp = res.minTemp.floatValue;
            
            line.minTempDot = minTempDot;
            line.maxTempDot = maxTempDot;
            
#warning 设置自定义线和框的高低温
            UIView *highView = [[UIView alloc] init];
            highView.frame = CGRectMake(0, 0, 20, 20);
            highView.backgroundColor = UIColor.cyanColor;
            line.maxTempDotView = highView;
            
            UIView *lowView = [[UIView alloc] init];
            lowView.frame = CGRectMake(0, 0, 20, 20);
            lowView.backgroundColor = UIColor.greenColor;
            line.minTempDotView = lowView;
        }
    }
    NSLog(@"self.canvas.items = %@" , self.canvas.items);
}

//截图
+(UIImage *)convertViewToImage:(UIView *)view scale:(CGFloat)scale{
    
    //    UIImage *imageRet = nil;
    //    //UIGraphicsBeginImageContextWithOptions(区域大小, 是否是非透明的, 屏幕密度);
    //    CZLogInfo(@"%@" , @([UIScreen mainScreen].scale));
    //    UIGraphicsBeginImageContextWithOptions(view.bounds.size, NO, scale);
    //    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    //    imageRet = UIGraphicsGetImageFromCurrentImageContext();
    //    UIGraphicsEndImageContext();
    //
    //    return imageRet;
    NSLog(@"%@" , view.layer.contents);
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(CGRectGetWidth(view.frame), CGRectGetHeight(view.frame)), NO, scale);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetInterpolationQuality(context, kCGInterpolationLow);
    CGContextSetFlatness(context, 0.1);
    [view drawViewHierarchyInRect:CGRectMake(0, 0, view.bounds.size.width, view.bounds.size.height) afterScreenUpdates:NO];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}


#pragma -mark Action

-(void)actionForSwitchPseudo
{
    self.presentView = [CZPresentView presentViewPositionCenterWithContainerView:self.containerView offset:CGPointMake(0, -100) displayView:self.pseudoSelectView hideAnimation:YES];
    self.presentView.titleLabel.hidden = NO;
    self.presentView.titleLabel.text = self.pseudoNames[IFClient.client.currentPseudoMode];
}

-(void)actionForSetBC
{
    self.presentView = [CZPresentView presentViewPositionBottonWithContainerView:self.containerView displayView:self.bcSetView hideAnimation:YES];
}

-(void)actionForEM
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"提示", nil) message:NSLocalizedString(@"请输入发射率", nil) preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"确定", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        UITextField *titleTextField = alertController.textFields.firstObject;
        if (!titleTextField.text.length) return;
        [IFClient.client setV_emissivity:titleTextField.text.floatValue];
    }];
    [alertController addAction:confirmAction];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"取消", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.keyboardType = UIKeyboardTypeDecimalPad;
    }];
    [self presentViewController:alertController animated:true completion:nil];
}

-(void)actionForTA
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"提示", nil) message:NSLocalizedString(@"请输入环境温度", nil) preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"确定", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        UITextField *titleTextField = alertController.textFields.firstObject;
        if (!titleTextField.text.length) return;
        [IFClient.client setV_environmental_temperature:titleTextField.text.floatValue];
    }];
    [alertController addAction:confirmAction];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"取消", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.keyboardType = UIKeyboardTypeDecimalPad;
    }];
    [self presentViewController:alertController animated:true completion:nil];
}

-(void)actionForDist
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"提示", nil) message:NSLocalizedString(@"请输入目标距离", nil) preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"确定", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        UITextField *titleTextField = alertController.textFields.firstObject;
        if (!titleTextField.text.length) return;
        [IFClient.client setV_target_distance:titleTextField.text.floatValue];
    }];
    [alertController addAction:confirmAction];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"取消", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.keyboardType = UIKeyboardTypeDecimalPad;
    }];
    [self presentViewController:alertController animated:true completion:nil];
}

//二次标定
-(void)actionForSettingLowTemp
{
    __weak typeof(self) weakSelf = self;
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"提示", nil) message:NSLocalizedString(@"请输入低温温度", nil) preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"确定", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        UITextField *titleTextField = alertController.textFields.firstObject;
        if (!titleTextField.text.length) return;
        weakSelf.lowTemp = titleTextField.text;
        [self.lowTempSettingButton setTitle:[NSString stringWithFormat:@"%@%@",NSLocalizedString(@"低温设置：", nil) , weakSelf.lowTemp] forState:UIControlStateNormal];
    }];
    [alertController addAction:confirmAction];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"取消", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.keyboardType = UIKeyboardTypeDecimalPad;
    }];
    [self presentViewController:alertController animated:true completion:nil];
}

-(void)actionForSettingHighTemp
{
    __weak typeof(self) weakSelf = self;
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"提示", nil) message:NSLocalizedString(@"请输入高温温度", nil) preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"确定", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action){
        UITextField *titleTextField = alertController.textFields.firstObject;
        if (!titleTextField.text.length) return;
        weakSelf.highTemp = titleTextField.text;
        [self.highTempSettingButton setTitle:[NSString stringWithFormat:@"%@%@",NSLocalizedString(@"高温设置：", nil) , weakSelf.highTemp] forState:UIControlStateNormal];
    }];
    [alertController addAction:confirmAction];
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"取消", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.keyboardType = UIKeyboardTypeDecimalPad;
    }];
    [self presentViewController:alertController animated:true completion:nil];
}

-(void)actionForCalibrationStarting
{
    __weak typeof(self) weakSelf = self;
    if (!_needCaculation) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [IFClient.client secondCalibrationWithDoubleLowPoint:self.lowTemp.floatValue comletion:^(BOOL success, NSError *e) {
            [hud hideAnimated:YES];
            if (!success) return;
            weakSelf.needCaculation = YES;
            [weakSelf.calibrationStartingButton setTitle:NSLocalizedString(@"点击开始高温标定", nil) forState:UIControlStateNormal];
        }];
        return;
    }
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [IFClient.client secondCalibrationWithDoubleHighPointTemp:self.highTemp.floatValue comletion:^(BOOL success, NSError *e) {
        //r/w flash操作时间长，耐心等待
        [hud hideAnimated:YES];
        if (!success) return;
        weakSelf.needCaculation = NO;
        [weakSelf.calibrationStartingButton setTitle:NSLocalizedString(@"点击开始低温标定", nil) forState:UIControlStateNormal];
    }];
}

-(void)actionForReset
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [IFClient.client clearCalibrationDataWithCompletion:^(BOOL success, NSError *e) {
        [hud hideAnimated:YES];
        if (success) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self actionForShutter];
            });
        }
    }];
}

-(void)actionForGainSwitch
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [IFClient.client cameraSetGainMode:!IFClient.gainStatus :^(BOOL success, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [hud hideAnimated:YES];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self actionForShutter];
            });
        });
    }];
}

-(void)actionForCal
{
    _calOpen = !_calOpen;
    self.lowTempSettingButton.hidden = self.highTempSettingButton.hidden = self.calibrationStartingButton.hidden = !_calOpen;
    //切换成标定后环境变量都会还原成默认值，不会记录
    if (_calOpen)
    {
        [IFClient.client setV_emissivity:1.0];
        [IFClient.client setV_environmental_temperature:25.0];
        [IFClient.client setV_target_distance:0.25];
    }
}

//旋转
-(void)actionForRotate
{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"旋转图像", nil) message:[self rotationString:IFClient.client.irRotationType] preferredStyle:UIAlertControllerStyleActionSheet];
    for (int index = 0; index < 4; index++) {
        [controller addAction:[UIAlertAction actionWithTitle:[self rotationString:index] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [IFClient.client setIrRotationType:index];
            [self updateCameraView:IFClient.client.irRotationType];
        }]];
    }
    [self presentViewController:controller animated:YES completion:nil];
}

-(NSString *)rotationString:(IFIRRotationType)type
{
    switch (type) {
        case IFIRRotationTypeOriginal:
            return NSLocalizedString(@"0°", nil);
        case IFIRRotationType90Degree:
            return NSLocalizedString(@"90°", nil);
        case IFIRRotationType180Degree:
            return NSLocalizedString(@"180°", nil);
        case IFIRRotationType270Degree:
            return NSLocalizedString(@"270°", nil);
        default:
            return @"";
    }
}

-(void)updateCameraView:(IFIRRotationType)irRotationType
{
    CGFloat containerWidth = self.view.bounds.size.width;
    
    if (irRotationType == IFIRRotationTypeOriginal || irRotationType == IFIRRotationType180Degree) {
        _imageWidth = 192;
        _imageHeight = 256;
        [self.cameraView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.mas_equalTo(0);
            make.height.mas_equalTo(containerWidth / _imageWidth * _imageHeight);
        }];
    }
    else {
        _imageWidth = 256;
        _imageHeight = 192;
        CGFloat portriatWidth = MIN(_imageWidth, _imageHeight);
        CGFloat portriatHeight = MAX(_imageWidth, _imageHeight);
        
        CGFloat uiHeight = containerWidth / _imageWidth * _imageHeight;
        CGFloat reversUIHeight = containerWidth / portriatWidth * portriatHeight;
        CGFloat calTop = (reversUIHeight - uiHeight)/2.0;
        [self.cameraView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(calTop);
            make.left.right.mas_equalTo(0);
            make.height.mas_equalTo(uiHeight);
        }];
    }
    
    [self.view layoutIfNeeded];
    [self.view setNeedsLayout];
    
    IFCanvasConfig *configer = [IFCanvasConfig new];
    configer.enableCustomTagName = YES;//默认自定义标签
    configer.contentWidth = self.cameraView.frame.size.width;
    configer.contentHeight = self.cameraView.frame.size.height;
    configer.imageWidth = _imageWidth;
    configer.imageHeight = _imageHeight;
    configer.tempPointRadius = 10;
#warning 设置点测温图片
    configer.dotIconImage = [UIImage imageNamed:@"canvas_dot_icon_select"];//设置点测温图片
#warning 客户自定义（不显示测温结果，客户自定义）
    configer.disableMeasureResultView = YES;
    self.canvas.setConfiger(configer);
    self.canvas.addSuperview(self.cameraView);
    [self refreshCanvasView];
}

-(void)refreshCanvasView;
{
    for (IFCanvasItemBase *item in self.canvas.items) {
        item.imageWidth = _imageWidth;
        item.imageHeight = _imageHeight;
        item.contentWidth = self.cameraView.bounds.size.width;
        item.contentHeight= self.cameraView.bounds.size.height;
        if ([item isKindOfClass:[IFCanvasItemDot class]]) {
            IFCanvasItemDot *dot = (IFCanvasItemDot *)item;
            CGPoint point = CGPointMake(dot.point.x, dot.point.y);
            [self.canvas.canvasView correctPoint:&point];
            dot.point = CGPointMake(point.x, point.y);
        }
        else {
            IFCanvasItemLine *line = (IFCanvasItemLine *)item;
            
            CGPoint startPoint = CGPointMake(line.startPoint.x, line.startPoint.y);
            [self.canvas.canvasView correctPoint:&startPoint];
            line.startPoint = CGPointMake(startPoint.x, startPoint.y);
            
            CGPoint endPoint = CGPointMake(line.endPoint.x, line.endPoint.y);
            [self.canvas.canvasView correctPoint:&endPoint];
            line.endPoint = CGPointMake(endPoint.x, endPoint.y);
        }
    }
}

-(void)actionForMirror
{
    [IFClient.client setMirrorIR:!IFClient.client.mirrorIR];
}

@end
