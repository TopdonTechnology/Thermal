//
//  CZPresentView.m
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import "CZPresentView.h"
#import "Masonry.h"

@interface CZPresentView ()
@property (nonatomic , strong) UIView *containerView;
@property (nonatomic , strong) UIView *displayView;
@property (nonatomic , strong) UIButton *maskButton;
@property (nonatomic , strong) UILabel *titleLabel;
@property (nonatomic) CGRect safeRect;
@property (nonatomic) BOOL maskNeedColor;

@end

@implementation CZPresentView

+(CZPresentView *)presentViewPositionBottonWithContainerView:(UIView *)containerView
                                           containerSafeRect:(CGRect)safeRect
                                                 displayView:(UIView *)displayView
                                               hideAnimation:(BOOL)animated
{
    CZPresentView *presentView = [[CZPresentView alloc] init];
    presentView.safeRect = safeRect;
    presentView.layer.masksToBounds = YES;
    presentView.containerView = containerView;
    presentView.displayView = displayView;
    presentView.frame = safeRect;
    presentView.maskButton.frame = presentView.bounds;
    [presentView addSubview:presentView.maskButton];
    displayView.frame = CGRectMake(0, CGRectGetHeight(safeRect), CGRectGetWidth(displayView.bounds), CGRectGetHeight(displayView.bounds));
    [presentView addSubview:displayView];
    [containerView addSubview:presentView];
    [UIView animateWithDuration:animated?0.3:0.0 animations:^{
        CGRect rect = displayView.frame;
        rect.origin.y = CGRectGetHeight(safeRect) - CGRectGetHeight(displayView.bounds);
        displayView.frame = rect;
    } completion:^(BOOL finished) {
        if (presentView.showCompletion) presentView.showCompletion();
    }];
    
    [presentView.titleLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(displayView.mas_top).offset(-10);
        make.width.mas_greaterThanOrEqualTo(0);
        make.height.mas_greaterThanOrEqualTo(0);
        make.centerX.mas_equalTo(displayView);
    }];
        
    displayView.layer.shadowColor = [UIColor.blackColor colorWithAlphaComponent:0.8].CGColor;
    displayView.layer.shadowOffset = CGSizeMake(0, 20); // 阴影偏移量，默认（0,0）
    displayView.layer.shadowOpacity = 1; // 不透明度
    displayView.layer.shadowRadius = [UIScreen mainScreen].bounds.size.width/375*10;
    
    return presentView;
}

+(CZPresentView *)presentViewPositionBottonWithContainerView:(UIView *)containerView
                                                 displayView:(UIView *)displayView
                                               hideAnimation:(BOOL)animated
{
    return [self presentViewPositionBottonWithContainerView:containerView displayView:displayView maskNeedColor:NO hideAnimation:YES];
}

+(CZPresentView *)presentViewPositionBottonWithContainerView:(UIView *)containerView
                                                 displayView:(UIView *)displayView
                                                maskNeedColor:(BOOL)maskNeedColor
                                               hideAnimation:(BOOL)animated{

    CZPresentView *presentView = [[CZPresentView alloc] init];
    presentView.maskNeedColor = YES;
    presentView.frame = containerView.bounds;
    presentView.containerView = containerView;
    presentView.displayView = displayView;
    presentView.maskButton.frame = presentView.bounds;
    [presentView addSubview:presentView.maskButton];
    displayView.frame = CGRectMake(0, CGRectGetHeight(containerView.bounds), CGRectGetWidth(displayView.bounds), CGRectGetHeight(displayView.bounds));
    [presentView addSubview:displayView];
    [containerView addSubview:presentView];
    
    [presentView.titleLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(displayView.mas_top).offset(-10);
        make.width.mas_greaterThanOrEqualTo(0);
        make.height.mas_greaterThanOrEqualTo(0);
        make.centerX.mas_equalTo(displayView);
    }];
    
    if (presentView.maskNeedColor) presentView.backgroundColor = UIColor.clearColor;
    [UIView animateWithDuration:animated?0.3:0.0 animations:^{
        CGRect rect = displayView.frame;
        rect.origin.y = CGRectGetHeight(containerView.bounds) - CGRectGetHeight(displayView.bounds);
        displayView.frame = rect;
        if (presentView.maskNeedColor) presentView.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.3];
    } completion:^(BOOL finished) {
        if (presentView.showCompletion) presentView.showCompletion();
    }];

    return presentView;
}

+(CZPresentView *)presentViewPositionCenterWithContainerView:(UIView *)containerView
                                                      offset:(CGPoint)offset
                                                 displayView:(UIView *)displayView
                                               hideAnimation:(BOOL)animated
{
    CZPresentView *presentView = [[CZPresentView alloc] init];
    presentView.maskNeedColor = YES;
    presentView.frame = containerView.bounds;
    presentView.containerView = containerView;
    presentView.displayView = displayView;
    presentView.maskButton.frame = presentView.bounds;
    [presentView addSubview:presentView.maskButton];
    displayView.frame = CGRectMake( (CGRectGetWidth(containerView.bounds) - CGRectGetWidth(displayView.bounds))/2.0 , CGRectGetHeight(containerView.bounds), CGRectGetWidth(displayView.bounds), CGRectGetHeight(displayView.bounds));
    [presentView addSubview:displayView];
    [containerView addSubview:presentView];
    
    [presentView.titleLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(displayView.mas_top).offset(-10);
        make.width.mas_greaterThanOrEqualTo(0);
        make.height.mas_greaterThanOrEqualTo(0);
        make.centerX.mas_equalTo(displayView);
    }];
    
    if (presentView.maskNeedColor) presentView.backgroundColor = UIColor.clearColor;
    [UIView animateWithDuration:animated?0.3:0.0 animations:^{
        CGRect rect = displayView.frame;
        rect.origin.y = (CGRectGetHeight(containerView.bounds) - CGRectGetHeight(displayView.bounds))/2.0 - offset.y;
        rect.origin.x -= offset.x;
        displayView.frame = rect;
        if (presentView.maskNeedColor) presentView.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.3];
    } completion:^(BOOL finished) {
        if (presentView.showCompletion) presentView.showCompletion();
    }];

    return presentView;
}


-(void)hideAnimation:(BOOL)animated
{
    if (self.titleLabel) self.titleLabel.hidden = YES;
    [UIView animateWithDuration:animated?0.3:0 animations:^{
        CGRect rect = self.displayView.frame;
        rect.origin.y = CGRectGetHeight(self.frame);
        self.displayView.frame = rect;
        if (self.maskNeedColor) self.backgroundColor = UIColor.clearColor;
    }completion:^(BOOL finished) {
        [self.maskButton removeFromSuperview];
        [self removeFromSuperview];
        
        if (self.hideCompletion)
            self.hideCompletion();
    }];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.maskButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.maskButton addTarget:self action:@selector(actionForHide) forControlEvents:UIControlEventTouchUpInside];
        
        self.titleLabel = [[UILabel alloc] init];
        self.titleLabel.font = [UIFont systemFontOfSize:12];
        self.titleLabel.backgroundColor = UIColor.blackColor;
        self.titleLabel.textColor = UIColor.whiteColor;
        self.titleLabel.layer.masksToBounds = YES;
        self.titleLabel.layer.cornerRadius = 4;
        [self addSubview:self.titleLabel];
        self.titleLabel.hidden = YES;
    }
    return self;
}

-(void)actionForHide
{
    [self hideAnimation:YES];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
