//
//  CZSetBCView.h
//  INFIP2Demo
//
//  Created by zsc-onlyyi on 2022/10/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CZSetBCView : UIView

@property (nonatomic , strong) void (^brightnessChanged)(int brightness);
@property (nonatomic , strong) void (^contrastChanged)(int contrast);

@end

NS_ASSUME_NONNULL_END
