//
//  CZPresentView.h
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import <UIKit/UIKit.h>

@interface CZPresentView : UIView

@property (nonatomic , readonly , strong) UILabel *titleLabel;
@property (nonatomic, strong) dispatch_block_t showCompletion;
@property (nonatomic, strong) dispatch_block_t hideCompletion;

+(CZPresentView *)presentViewPositionBottonWithContainerView:(UIView *)containerView
                                           containerSafeRect:(CGRect)safeRect
                                                 displayView:(UIView *)displayView
                                               hideAnimation:(BOOL)animated;

+(CZPresentView *)presentViewPositionBottonWithContainerView:(UIView *)containerView
                                                 displayView:(UIView *)displayView
                                               hideAnimation:(BOOL)animated;

+(CZPresentView *)presentViewPositionCenterWithContainerView:(UIView *)containerView
                                                      offset:(CGPoint)offset
                                                 displayView:(UIView *)displayView
                                               hideAnimation:(BOOL)animated;


+(CZPresentView *)presentViewPositionBottonWithContainerView:(UIView *)containerView
                                                 displayView:(UIView *)displayView
                                                maskNeedColor:(BOOL)maskNeedColor
                                               hideAnimation:(BOOL)animated;
-(void)hideAnimation:(BOOL)animated;

@end
