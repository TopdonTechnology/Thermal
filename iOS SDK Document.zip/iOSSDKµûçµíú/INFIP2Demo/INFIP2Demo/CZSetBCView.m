//
//  CZSetBCView.m
//  INFIP2Demo
//
//  Created by zsc-onlyyi on 2022/10/18.
//

#import "CZSetBCView.h"
#import "Masonry.h"

@interface CZSetBCView ()
@property (nonatomic , strong) UISlider *brightnessProgessView;
@property (nonatomic , strong) UISlider *contrastProgessView;
@property (nonatomic , strong) UILabel *brightnessInfoLabel;
@property (nonatomic , strong) UILabel *contrastInfoLabel;

@end

@implementation CZSetBCView

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        [self setUp];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setUp];
    }
    return self;
}

-(void)setUp
{
    self.brightnessProgessView = [[UISlider alloc] init];
    [self.brightnessProgessView addTarget:self action:@selector(actionForBrightnessSlideChanged) forControlEvents:UIControlEventValueChanged];
    self.brightnessProgessView.minimumTrackTintColor = UIColor.whiteColor;
    self.brightnessProgessView.maximumTrackTintColor = UIColor.blueColor;
    self.brightnessProgessView.maximumValue = 255;
    self.brightnessProgessView.minimumValue = 0;
    self.brightnessProgessView.value = 128;
    self.brightnessProgessView.continuous = YES;
    [self addSubview:self.brightnessProgessView];
    
    self.brightnessInfoLabel = [[UILabel alloc] init];
    self.brightnessInfoLabel.text = NSLocalizedString(@"亮度:128", nil);
    [self addSubview:self.brightnessInfoLabel];
    
    [self.brightnessInfoLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(15);
        make.top.mas_equalTo(10);
        make.size.mas_greaterThanOrEqualTo(0);
    }];
    
    [self.brightnessProgessView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.brightnessInfoLabel.mas_bottom).offset(10);
        make.left.mas_equalTo(self.brightnessInfoLabel);
        make.centerX.mas_equalTo(0);
        make.height.mas_equalTo(80);
    }];
    
    
    self.contrastProgessView = [[UISlider alloc] init];
    [self.contrastProgessView addTarget:self action:@selector(actionForContrastSlideChanged) forControlEvents:UIControlEventValueChanged];
    self.contrastProgessView.minimumTrackTintColor = UIColor.whiteColor;
    self.contrastProgessView.maximumTrackTintColor = UIColor.blueColor;
    self.contrastProgessView.maximumValue = 255;
    self.contrastProgessView.minimumValue = 0;
    self.contrastProgessView.value = 128;
    self.contrastProgessView.continuous = YES;
    [self addSubview:self.contrastProgessView];
    
    self.contrastInfoLabel = [[UILabel alloc] init];
    self.contrastInfoLabel.text = NSLocalizedString(@"对比度:128", nil);
    [self addSubview:self.contrastInfoLabel];
    
    [self.contrastInfoLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(15);
        make.top.mas_equalTo(self.brightnessProgessView.mas_bottom).offset(10);
        make.size.mas_greaterThanOrEqualTo(0);
    }];
    
    [self.contrastProgessView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.contrastInfoLabel.mas_bottom).offset(10);
        make.left.mas_equalTo(self.contrastInfoLabel);
        make.centerX.mas_equalTo(0);
        make.height.mas_equalTo(80);
    }];
}

-(void)actionForBrightnessSlideChanged
{
    self.brightnessInfoLabel.text = [NSString stringWithFormat:@"%@:%@",NSLocalizedString(@"亮度", nil),@((int)self.brightnessProgessView.value)];
    if (self.brightnessChanged) self.brightnessChanged((int)self.brightnessProgessView.value);
}

-(void)actionForContrastSlideChanged
{
    self.contrastInfoLabel.text = [NSString stringWithFormat:@"%@:%@",NSLocalizedString(@"对比度", nil),@((int)self.contrastProgessView.value)];
    if (self.contrastChanged) self.contrastChanged((int)self.contrastProgessView.value);
}
@end
