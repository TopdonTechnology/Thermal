//
//  AppDelegate.m
//  INFIP2Demo
//
//  
//

#import "AppDelegate.h"
#import "CZHomeViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame: [[UIScreen mainScreen] bounds]];
    CZHomeViewController *homeVC = [[CZHomeViewController alloc] init];
    UINavigationController *naviVC = [[UINavigationController alloc] initWithRootViewController:homeVC];
    self.window.rootViewController = naviVC;
    [self.window makeKeyAndVisible];
    return YES;
}

-(UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    return UIInterfaceOrientationMaskPortrait;
}

@end
