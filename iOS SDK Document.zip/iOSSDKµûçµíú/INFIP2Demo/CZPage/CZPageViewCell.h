//
//  CZPageViewCell.h
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import <UIKit/UIKit.h>
#import "CZPseudoItem.h"

@interface CZPageViewCell : UICollectionViewCell
@property (nonatomic , strong) CZPseudoItem *item;
@end
