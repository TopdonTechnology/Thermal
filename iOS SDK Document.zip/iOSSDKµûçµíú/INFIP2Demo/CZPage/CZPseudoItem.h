//
//  CZPseudoItem.h
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import <UIKit/UIKit.h>
#import <INFIP2SDK/INFIP2SDK.h>

@interface CZPseudoItem : NSObject

@property (nonatomic) IFPseudoMode mode;
@property (nonatomic , strong) UIImage *image;
@property (nonatomic , copy) NSString *name;

@end
