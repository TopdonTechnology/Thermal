//
//  CZPageView.h
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import <UIKit/UIKit.h>
#import "CZPseudoItem.h"

@protocol CZPageViewDelegate <NSObject>

-(void)pageViewDidSelectPseudoMode:(IFPseudoMode)model;

-(void)pageViewDidEndDeceleratingSelectPseudoMode:(IFPseudoMode)model;

@end

@interface CZPageView : UICollectionView

@property (nonatomic , strong ,readonly) NSArray<CZPseudoItem *> *selectItems;

@property (nonatomic , weak) id<CZPageViewDelegate> czDelegate;

-(instancetype)initWithSelectItems:(NSArray<CZPseudoItem *> *)selectItems itemSize:(CGSize)itemSize;

-(void)reloadVisibleCells;

-(void)updateItemSize:(CGSize)size;

-(void)setIndex:(NSUInteger)index;

@end
