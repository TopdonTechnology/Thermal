//
//  CZPageView.m
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import "CZPageView.h"
#import "CZPageViewFlowLayout.h"
#import "CZPageViewCell.h"


#define itemSpacing 20

@interface CZPageView ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic , strong) NSArray<CZPseudoItem *> *selectItems;
@property (nonatomic) CGSize itemSize;

@end

@implementation CZPageView

-(instancetype)initWithSelectItems:(NSArray<CZPseudoItem *> *)selectItems itemSize:(CGSize)itemSize
{
    UICollectionViewFlowLayout *layout = [[CZPageViewFlowLayout alloc] init];
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    layout.minimumLineSpacing = itemSpacing;
    layout.minimumInteritemSpacing = 0;
    layout.itemSize = itemSize;
    
    self = [super initWithFrame:CGRectZero collectionViewLayout:layout];
    if(self){
        _itemSize = itemSize;
        _selectItems = selectItems;
        [self initUI];
    }
    return self;
}

-(void)initUI
{
    self.decelerationRate = UIScrollViewDecelerationRateFast;
    self.clipsToBounds = NO;
    self.delegate = self;
    self.dataSource = self;
    self.backgroundColor = [UIColor clearColor];
    self.scrollEnabled = YES;
    self.showsVerticalScrollIndicator = self.showsHorizontalScrollIndicator = NO;
    [self registerClass:[CZPageViewCell class] forCellWithReuseIdentifier:NSStringFromClass([CZPageViewCell class])];
}

#pragma mark - UICollectionViewDataSource / UICollectionViewDelegate
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.selectItems.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CZPageViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([CZPageViewCell class]) forIndexPath:indexPath];
    cell.item = self.selectItems[indexPath.row];
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat x = (self.itemSize.width+itemSpacing) * indexPath.row;
    [self setContentOffset:CGPointMake(x, 0) animated:YES];

}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView;
{
    [self scrollViewDidEndDecelerating:scrollView];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    int index = round(scrollView.contentOffset.x/(self.itemSize.width+itemSpacing));
    if (index < 0 || index >= self.selectItems.count) {
        return;
    }
    CZPseudoItem *item = self.selectItems[index];
    if (self.czDelegate && [self.czDelegate respondsToSelector:@selector(pageViewDidSelectPseudoMode:)]) {
        [self.czDelegate pageViewDidSelectPseudoMode:item.mode];
    }
}
    
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    int index = round(scrollView.contentOffset.x/(self.itemSize.width+itemSpacing));
    if (index < 0 || index >= self.selectItems.count) {
        return;
    }
    CZPseudoItem *item = self.selectItems[index];
    if (self.czDelegate && [self.czDelegate respondsToSelector:@selector(pageViewDidSelectPseudoMode:)]) {
        [self.czDelegate pageViewDidSelectPseudoMode:item.mode];
    }
    
    if (self.czDelegate && [self.czDelegate respondsToSelector:@selector(pageViewDidEndDeceleratingSelectPseudoMode:)]) {
        [self.czDelegate pageViewDidEndDeceleratingSelectPseudoMode:item.mode];
    }
}

-(void)reloadVisibleCells
{
    NSArray *cells = [self visibleCells];
    for (CZPageViewCell *cell in cells) {
        NSUInteger index = [self.selectItems indexOfObject:cell.item];
        [cell setItem:self.selectItems[index]];
    }
}

-(void)updateItemSize:(CGSize)size
{
    ((UICollectionViewFlowLayout *)self.collectionViewLayout).itemSize = size;
}

- (void)setIndex:(NSUInteger)index
{
    if (index >= self.selectItems.count) return;
    CGFloat x = (self.itemSize.width+itemSpacing) * index;
    [self setContentOffset:CGPointMake(x, 0) animated:NO];
}
@end
