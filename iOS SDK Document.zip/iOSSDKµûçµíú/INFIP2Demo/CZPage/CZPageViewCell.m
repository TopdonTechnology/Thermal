//
//  CZPageViewCell.m
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import "CZPageViewCell.h"
#import "Masonry.h"

@interface CZPageViewCell ()

@property (nonatomic , strong) UIImageView *imgView;

@end

@implementation CZPageViewCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.imgView = [[UIImageView alloc] initWithFrame:self.bounds];
        self.imgView.layer.cornerRadius = 4.f;
        self.imgView.layer.borderColor = UIColor.whiteColor.CGColor;
        self.imgView.layer.borderWidth = 2;
        self.imgView.layer.masksToBounds = YES;
        [self.contentView addSubview:self.imgView];
        [self.imgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
    }
    return self;
}

- (void)setItem:(CZPseudoItem *)item
{
    _item = item;
    
    if (!item.image) return;

    self.imgView.image = item.image;
    
}



@end
