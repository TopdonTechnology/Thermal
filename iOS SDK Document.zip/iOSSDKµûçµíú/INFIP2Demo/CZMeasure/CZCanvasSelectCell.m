//
//  CZCanvasSelectCell.m
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import "CZCanvasSelectCell.h"
#import "Masonry.h"

@interface CZCanvasSelectCell ()

@property (nonatomic , strong) UIImageView *iconImageView;
@property (nonatomic , strong) UIImageView *bgImageView;
@property (nonatomic , strong) UILabel *titleLabel;

@end

@implementation CZCanvasSelectCell

-(instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.contentView.clipsToBounds = NO;
        self.clipsToBounds = NO;
        
        self.bgImageView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.bgImageView];
        [self.bgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
        self.iconImageView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.iconImageView];
        [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(26);
            make.centerX.mas_equalTo(0);
            make.top.mas_equalTo(11);
        }];
        
        self.titleLabel = [[UILabel alloc] init];
        self.titleLabel.font = [UIFont systemFontOfSize:11];
        self.titleLabel.textColor = UIColor.whiteColor;
        [self.contentView addSubview:self.titleLabel];
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_greaterThanOrEqualTo(0);
            make.centerX.mas_equalTo(0);
            make.bottom.mas_equalTo(-10);
        }];
        
    }
    return self;
}


- (void)setItem:(CZCanvasSelectItem *)item
{
    _item = item;
    self.titleLabel.text = item.title;
    self.iconImageView.image = item.selected?item.iconSelectImage:item.iconNormalImage;
//    self.bgImageView.backgroundColor = item.selected?CZAssertsUtil.lightBgColor:UIColor.clearColor;
    self.titleLabel.textColor = item.selected?[UIColor colorWithRed:0 green:156/255.0 blue:246/255.0 alpha:1.0]:UIColor.whiteColor;
    self.iconImageView.alpha = self.titleLabel.alpha = item.highlighted?0.3:1.0;
    self.contentView.alpha = item.disable?0.5:1.0;
}

@end
