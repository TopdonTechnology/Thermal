//
//  CZCanvasSelectView.m
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import "CZMeasureSelectView.h"
#import "CZCanvasSelectCell.h"

static CGFloat padding = 0;

@interface CZMeasureSelectView ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic , strong)NSArray<CZCanvasSelectItem *> * selectItems;
@property (nonatomic , strong)CZCanvasSelectCell * selectCell;
@property (nonatomic , strong)CZCanvasSelectCell * selectIsotherCell;

@end

@implementation CZMeasureSelectView

-(instancetype)initWithSelectItems:(NSArray<CZCanvasSelectItem *> *)selectItems frame:(CGRect)frame
{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    layout.minimumLineSpacing = padding;
    layout.minimumInteritemSpacing = padding;
    
    self = [super initWithFrame:frame collectionViewLayout:layout];
    if(self){
        _selectItems = selectItems;
        [self initUI];
    }
    return self;
}

-(void)initUI
{
    self.clipsToBounds = NO;
    self.delegate = self;
    self.dataSource = self;
    self.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.8];
    self.scrollEnabled = NO;
    self.alwaysBounceVertical = YES;
    [self registerClass:[CZCanvasSelectCell class] forCellWithReuseIdentifier:NSStringFromClass([CZCanvasSelectCell class])];
}

#pragma mark - UICollectionViewDataSource / UICollectionViewDelegate
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.selectItems.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CZCanvasSelectCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([CZCanvasSelectCell class]) forIndexPath:indexPath];
    cell.item = self.selectItems[indexPath.row];
    return cell;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat itemSizeValue = 68;
    return CGSizeMake(self.bounds.size.width/self.selectItems.count , itemSizeValue);
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    CZCanvasSelectCell *cell = (CZCanvasSelectCell *)[self cellForItemAtIndexPath:indexPath];
    CZCanvasSelectItem *item = self.selectItems[indexPath.row];
    
    if (item.selectType == CZCanvasSelectTypeIsother) {
        self.selectIsotherCell = cell;

        if (item.disable) return;
        
        item.selected = !item.selected;
        cell.item = item;
        
        if (self.czDelegate && [self.czDelegate respondsToSelector:@selector(isotherEnableChanged:)]) {
            [self.czDelegate isotherEnableChanged:item.selected];
        }
        
        return;
    }
    
    if (self.selectCell) {
        CZCanvasSelectItem *item = self.selectCell.item;
        item.selected = NO;
        self.selectCell.item = item;
    }
    
    if (item.selectType == CZCanvasSelectTypeDelete) {
        //删除
        if (self.selectIsotherCell) {
            CZCanvasSelectItem *i = self.selectIsotherCell.item;
            if (!i.disable) {
                i.selected = NO;
                self.selectIsotherCell.item = i;
            }
        }
        
        if (self.czDelegate && [self.czDelegate respondsToSelector:@selector(isotherEnableChanged:)]) {
            [self.czDelegate isotherEnableChanged:item.selected];
        }
        
        if (self.czDelegate && [self.czDelegate respondsToSelector:@selector(measureTempViewDidSelectCanvasType:)]) {
            [self.czDelegate measureTempViewDidSelectCanvasType:item.selectType];
        }
        return;
    }
    
    item.selected = YES;
    cell.item = item;
    self.selectCell = cell;
    
    if (self.czDelegate && [self.czDelegate respondsToSelector:@selector(measureTempViewDidSelectCanvasType:)]) {
        [self.czDelegate measureTempViewDidSelectCanvasType:item.selectType];
    }
}

- (void)collectionView:(UICollectionView *)collectionView didHighlightItemAtIndexPath:(NSIndexPath *)indexPath
{
    CZCanvasSelectCell *cell = (CZCanvasSelectCell *)[self cellForItemAtIndexPath:indexPath];
    CZCanvasSelectItem *item = self.selectItems[indexPath.row];
    item.highlighted = YES;
    cell.item = item;
}

- (void)collectionView:(UICollectionView *)collectionView didUnhighlightItemAtIndexPath:(NSIndexPath *)indexPath
{
    CZCanvasSelectCell *cell = (CZCanvasSelectCell *)[self cellForItemAtIndexPath:indexPath];
    CZCanvasSelectItem *item = self.selectItems[indexPath.row];
    item.highlighted = NO;
    cell.item = item;
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(padding, padding, padding, padding);
}

-(BOOL)disableIsotherReturnIsotherSelected:(BOOL)disable;
{
    CZCanvasSelectItem *item = self.selectItems[CZCanvasSelectTypeIsother];
    item.disable = disable;
    [self reloadData];
    return item.selected;
}

-(void)updateSelectItems:(NSArray<CZCanvasSelectItem *> *)updateItems
{
    self.selectItems = updateItems;
    [self reloadData];
}

- (void)dealloc
{
    
}


@end
