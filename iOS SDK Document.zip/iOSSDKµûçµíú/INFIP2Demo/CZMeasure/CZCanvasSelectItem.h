//
//  CZCanvasSelectItem.h
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    CZCanvasSelectTypeDot,
    CZCanvasSelectTypeLine,
    CZCanvasSelectTypeRect,
    CZCanvasSelectTypeIsother,
    CZCanvasSelectTypeDelete
} CZCanvasSelectType;

@interface CZCanvasSelectItem : NSObject

@property (nonatomic) CZCanvasSelectType selectType;
@property (nonatomic) bool selected;
@property (nonatomic,readonly,strong) UIImage *iconNormalImage;
@property (nonatomic,readonly,strong) UIImage *iconSelectImage;
@property (nonatomic) bool highlighted;
@property (nonatomic,strong) NSString *title;
@property (nonatomic) bool disable;
@property (nonatomic) bool supportedAllOrientation;

@end
