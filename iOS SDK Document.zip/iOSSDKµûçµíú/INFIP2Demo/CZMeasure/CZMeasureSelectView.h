//
//  CZCanvasSelectView.h
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import <UIKit/UIKit.h>

#import "CZCanvasSelectItem.h"

@protocol CZCanvasSelectViewDelegate <NSObject>

@optional

-(void)measureTempViewDidSelectCanvasType:(CZCanvasSelectType)type;

-(void)isotherEnableChanged:(BOOL)isotherEnable;

@end

@interface CZMeasureSelectView : UICollectionView

@property (nonatomic , assign) id<CZCanvasSelectViewDelegate> czDelegate;

-(instancetype)initWithSelectItems:(NSArray<CZCanvasSelectItem *> *)selectItems frame:(CGRect)frame;

-(BOOL)disableIsotherReturnIsotherSelected:(BOOL)disable;

-(void)updateSelectItems:(NSArray<CZCanvasSelectItem *> *)updateItems;

@end
