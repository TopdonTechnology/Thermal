//
//  CZCanvasSelectItem.m
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/8.
//

#import "CZCanvasSelectItem.h"


@implementation CZCanvasSelectItem

-(UIImage *)iconNormalImage
{
    switch (self.selectType) {
        case CZCanvasSelectTypeDot:
            return [UIImage imageNamed:@"canvas_dot_icon_normal"];
        case CZCanvasSelectTypeLine:
            return [UIImage imageNamed:@"canvas_line_icon_normal"];
        case CZCanvasSelectTypeRect:
            return [UIImage imageNamed:@"canvas_rect_icon_normal"];
        case CZCanvasSelectTypeIsother:
            return [UIImage imageNamed:@"canvas_isother_icon_normal"];
        case CZCanvasSelectTypeDelete:
            return [UIImage imageNamed:@"photo_library_delete_image"];
        default:
            return nil;
    }
}

-(UIImage *)iconSelectImage
{
    switch (self.selectType) {
        case CZCanvasSelectTypeDot:
            return [UIImage imageNamed:@"canvas_dot_icon_select"];
        case CZCanvasSelectTypeLine:
            return [UIImage imageNamed:@"canvas_line_icon_select"];
        case CZCanvasSelectTypeRect:
            return [UIImage imageNamed:@"canvas_rect_icon_select"];
        case CZCanvasSelectTypeIsother:
            return [UIImage imageNamed:@"canvas_isother_icon_select"];
        case CZCanvasSelectTypeDelete:
            return [UIImage imageNamed:@"photo_library_delete_image_select"];
        default:
            return nil;
    }
}


@end
