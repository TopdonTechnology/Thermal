## Special attention:
Warmer temperature
- 1, the first time the module is inserted, the screen shows that the i o s time may be a little longer, about 2 to 3 seconds, because the first time, there is a reading module flash time, the second time will not be used.

- 2, every time you enter the screen, the temperature data is not accurate, at this time we will hit the shutter temperature. Pay special attention to the number of times the shutter is hit here, because the temperature of the shutter is not accurate.

You can play at the following rhythm:
Events for 20 seconds: 19 seconds Once the shutter -- -- -- -- -- - > 16 seconds to play a shutter -- -- -- -- -- -- -- -- -- -- > 13 seconds to play a shutter -- -- -- -- -- -- -- > 8 seconds to play a shutter -- -- -- -- -- -- -- > 5 seconds to play a shutter

The time to hit the shutter is to hit the shutter and set some parameters after the agent callback has data.

Exit screen Note: Please call the delete agent, call the stop chart, only after the stop chart is successful in the return to the previous page.
