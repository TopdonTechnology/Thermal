SDK简介 【Introduction to SDK】
===============================

P2 iOS SDK
实现了iOS系统下P2系列红外摄像头应用接口，为客户提供参考demo和底层封装库方面客户二次开发，后面章节统一称为
SDK 。

【The P2 iOS SDK implements the Falcon series infrared camera application
interface under the iOS system, and provides customers with reference demos and
the secondary development of the underlying package library. The following
chapters are collectively referred to as SDK.】



SDK 【SDK development environment】
===================================

Xcode 12.4.1+

iOS11+

SDK引入【SDK introduction】
===========================

步骤一【Step 1】
----------------

将INFIP2SDK.framework放入主工程下【Put the INFIP2SDK.framework in the project
directory】

![](接口开发说明文档 Interface development instructions.images/zu2Jr0.png)

 

步骤二【Step 2】
----------------

Xcode -\> Targets -\> General -\> Frameworks, Libraries, and Embedded Content

对应INFIP2SDK.framework选择Embed & Sign或Embed Without Signing.

【Xcode -\> Targets -\> General -\> Frameworks, Libraries, and Embedded Content

Choose INFIP2SDK.framework to Embed & Sign or Embed Without Signing.】

![](接口开发说明文档 Interface development instructions.images/4lzqSn.png)

 

步骤三【Step 3】
----------------

将INFIP2SDK.framework中的IFBundle.bundle放入主工程下

【Put the IFBundle.bundle in INFIP2SDK.framework in the project directory】

![](接口开发说明文档 Interface development instructions.images/YdVF5P.png)

 

步骤四【Step 4】
----------------

Xcode -\> Targets -\> Info 添加键”Supported external accessory
protocols”为”com.alcorlink.camera"

【Xcode -\> Targets -\> Info  add ”Supported external accessory protocols” set
”com.alcorlink.camera".】

对应INFIP2SDK.framework选择Embed & Sign或Embed Without Signing.

![](接口开发说明文档 Interface development instructions.images/R1aA4I.png)

 

接口使用说明【API Guide】
=========================

【Refer to interface documentation and [Sample
Code](SampleCode/INFIP2Demo/INFIP2Demo.xcworkspace)】

请参考接口文档和[Sample Code](SampleCode/INFIP2Demo/INFIP2Demo.xcworkspace)。

 
