//
//  IFCanvasView.h
//  IFUISDK
//
//  Created by zsc-onlyyi on 2022/3/18.
//

#import <UIKit/UIKit.h>
#import "IFDrawEnum.h"
#import "IFCanvasConfig.h"
#import "IFCanvasItemBase.h"
#import "IFTempResultContainerView.h"

@interface IFCanvasView : UIView

@property (nonatomic , setter=setShapeType:) IFDrawShapeType shapeType;
@property (nonatomic , setter=setDrawType:) IFDrawType drawType;
@property (nonatomic , strong) IFCanvasConfig *configer;
@property (nonatomic , strong , readonly) NSMutableDictionary<NSNumber * ,NSArray *> *items;
@property (nonatomic , strong) IFCanvasItemDot *maxTempItemDot;
@property (nonatomic , strong) IFCanvasItemDot *minTempItemDot;
@property (nonatomic , strong) IFCanvasItemDot *centerTempItemDot;

@property (nonatomic , strong) IFCanvasItemDot *highlightTempItemDot;
@property (nonatomic , strong) IFCanvasItemDot *targetTempItemDot;
//add new control items count : default:simple=unsupported professional=3)
@property (nonatomic , strong) NSNumber *shaperCount;

@property (nonatomic,strong,readonly) UIView *out_targetTempItemDotView;

@property (nonatomic , strong) void(^canvasChanged)(BOOL isDrawing);
@property (nonatomic , strong) void(^didSelectItem)(IFCanvasItemBase *item);
@property (nonatomic,strong,readonly) IFTempResultContainerView *tempResultContainerView;

-(void)clearSimpleShapeViews;
-(IFCanvasItemBase *)moveToDrawShape:(CGPoint)startPoint
                            endPoint:(CGPoint)endPoint
                        needSaveView:(BOOL)saved;
-(void)clearAllViews;
-(void)correctPoint:(CGPoint *)point;
-(void)layoutResultViews;

@end
