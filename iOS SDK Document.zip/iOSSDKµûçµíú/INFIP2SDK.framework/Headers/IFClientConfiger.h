//
//  IFClientConfiger.h
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/5/17.
//

#import <Foundation/Foundation.h>

@protocol IFClientConfigerParam <NSObject>

@property (nonatomic , readonly) int fps; ///设置fps 默认: 25fps
@property (nonatomic , readonly) int pixelWidth; ///像素宽 默认: 260
@property (nonatomic , readonly) int pixelHeight; ///像素高 默认: 204
@property (nonatomic , readonly) int cropPixelWidth; ///剪裁像素宽 像素宽 默认: 256
@property (nonatomic , readonly) int cropPixelHeight; ///剪裁像素高 像素高 默认: 192
@property (nonatomic , copy) NSString *protocolString;///通信协议

@end

@interface IFClientConfiger : NSObject<IFClientConfigerParam>

@end
