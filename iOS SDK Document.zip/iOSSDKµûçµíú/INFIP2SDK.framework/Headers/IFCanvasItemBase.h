//
//  IFCanvasItemBase.h
//  IFUISDK
//
//  Created by zsc-onlyyi on 2022/3/18.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, IFOrientaion) {
    IFOrientationPortraitUnknow,
    IFOrientationPortrait,            // Device oriented vertically, home button on the bottom
    IFOrientationPortraitUpsideDown,  // Device oriented vertically, home button on the top
    IFOrientationLandscapeLeft,       // Device oriented horizontally, home button on the right
    IFOrientationLandscapeRight,      // Device oriented horizontally, home button on the left
};

NS_ASSUME_NONNULL_BEGIN

@interface IFCanvasItemBase : NSObject
@property (nonatomic , strong) UIColor *mainColor;//主色调
@property (nonatomic) CGFloat lineWidth;//边框宽度
@property (nonatomic , strong) UIColor *textColor;//文本颜色
@property (nonatomic , strong) UIFont *textFont;//文字字体
@property (nonatomic) NSInteger index;//测温UI索引
@property (nonatomic) NSInteger imageWidth;///图片宽度
@property (nonatomic) NSInteger imageHeight;///图片高度
@property (nonatomic) NSInteger contentWidth;///内容宽度
@property (nonatomic) NSInteger contentHeight;///内容高度
@property (nonatomic) IFOrientaion orientation;//选装状态
@property (nonatomic,copy,readonly) NSString *tagName;//标签名
@property (nonatomic,copy) NSString *customName;//自定义标签名
@property (nonatomic) BOOL autoResizeLabel;//UILabel是否自动选装
@property (nonatomic) BOOL disableAnimated;//关闭旋转动画
@property (nonatomic,copy) NSString *tempUnit;//温度单位
@property (nonatomic,copy) NSString *resultMaxTempPre;//高温显示前缀文案
@property (nonatomic,copy) NSString *resultMinTempPre;//低温显示前缀文案
@property (nonatomic,copy) NSString *resultAverageTempPre;//平均温显示前缀文案
@property (nonatomic,copy) NSString *resultPointTempPre;//点温显示前缀文案
@property (nonatomic,assign) BOOL disableGesture;//关闭滑动
@property (nonatomic) BOOL enableCustomTagName;//开启自定义标签
@property (nonatomic,weak) UIView *itemView;//绘制的view
//UI转换实际像素坐标点
-(CGPoint)imagePointToUIPoint:(CGPoint)imagePoint;
@end

@interface IFCanvasItemDot : IFCanvasItemBase
@property (nonatomic) CGPoint point;//点在UI上的位置
@property (nonatomic) CGFloat radius;//点弧度设置
@property (nonatomic) CGPoint textOffset;//点文案偏移量
@property (nonatomic) float pointTemp;//点温度设置
@property (nonatomic,readonly) CGPoint imagePoint;//点在原始图像位置
@property (nonatomic,strong) UIColor *centerPointColor;//箭头中心点颜色
@property (nonatomic) BOOL hideArrow;//隐藏箭头
@property (nonatomic) float arrowLength;//绘图箭头长度
@property (nonatomic) BOOL isTarget;//SDK内部逻辑
@property (nonatomic,strong) UIImage *iconImage;//设置成图片后将不在使用绘图模式

@end


@interface IFCanvasItemLine : IFCanvasItemBase

@property (nonatomic) CGPoint startPoint;//UI绘制起始点
@property (nonatomic) CGPoint endPoint;//UI绘制终点
@property (nonatomic , strong) IFCanvasItemDot *minTempDot;//高温点
@property (nonatomic , strong) IFCanvasItemDot *maxTempDot;//低温点
@property (nonatomic,readonly) CGPoint rectImageStartPoint;//框起始点
@property (nonatomic,readonly) CGPoint rectImageEndPoint;//框终点
@property (nonatomic,readonly) CGPoint lineImageStartPoint;//线起始点
@property (nonatomic,readonly) CGPoint lineImageEndPoint;//线终点
@property (nonatomic) float averageTemp;//平均温度
@property (nonatomic , strong) UIView *minTempDotView;//高温点UI
@property (nonatomic , strong) UIView *maxTempDotView;//低温点UI

@property (nonatomic , readonly) float areaWidth;//绘制图像像素宽度
@property (nonatomic , readonly) float areaHeight;//绘制图像像素高度

@end


@interface IFCanvasItemRect : IFCanvasItemLine
//同IFCanvasItemLine
@end

@interface IFCanvasItemCircle : IFCanvasItemLine
//待开发
@end


NS_ASSUME_NONNULL_END
