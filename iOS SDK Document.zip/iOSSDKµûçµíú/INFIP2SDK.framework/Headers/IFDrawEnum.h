//
//  IFDrawEnum.h
//  IFUISDK
//
//  Created by zsc-onlyyi on 2022/3/18.
//

typedef enum : NSUInteger {
    IFDrawShapeTypeNone,
    IFDrawShapeTypePoint,
    IFDrawShapeTypeLine,
    IFDrawShapeTypeRect,
    IFDrawShapeTypeCircle,
} IFDrawShapeType;

typedef enum : NSUInteger {
    IFDrawTypeSimple,
    IFDrawTypeProfessional
} IFDrawType;


#define IF_DEFAULT_CONTENT_WIDTH 256
#define IF_DEFAULT_CONTENT_HEIGHT 192
#define IF_INVALID_MOVE_AREA_PADDING 1
#define IF_MAX_ITEM_COUNT 3
