//
//  INFIP2SDK.h
//  INFIP2SDK
//
//  Created by zsc-onlyyi on 2022/7/25.
//

#import <Foundation/Foundation.h>

//! Project version number for INFIP2SDK.
FOUNDATION_EXPORT double INFIP2SDKVersionNumber;

//! Project version string for INFIP2SDK.
FOUNDATION_EXPORT const unsigned char INFIP2SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <INFIP2SDK/PublicHeader.h>

#import <INFIP2SDK/IFClient.h>
#import <INFIP2SDK/IFISPImageHandleInterface.h>
#import <INFIP2SDK/IFPseudoColorTable.h>
#import <INFIP2SDK/CZDevice.h>
#import <INFIP2SDK/IFDrawEnum.h>
#import <INFIP2SDK/IFCanvasConfig.h>
#import <INFIP2SDK/IFCanvasItemBase.h>
#import <INFIP2SDK/IFTempResultContainerView.h>
#import <INFIP2SDK/IFCanvas.h>
#import <INFIP2SDK/IFSubChainView.h>
#import <INFIP2SDK/IFCanvasView.h>
