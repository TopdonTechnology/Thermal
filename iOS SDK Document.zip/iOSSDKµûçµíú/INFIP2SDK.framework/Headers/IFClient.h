//
//  IFClient.h
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/21.
//

#import "IFClientConfiger.h"
#import "IFISPImageHandleInterface.h"
#import "IFPseudoColorTable.h"

@interface IFClient : NSObject<IFISPImageHandleInterface>
///单例
@property (nonatomic , strong , class , readonly)IFClient *client;
//增益状态（true: 高增益 false：低增益）
@property (nonatomic , class) BOOL gainStatus;
//PN查询
@property (nonatomic , copy , readonly)NSString *pn;
//SN查询
@property (nonatomic , copy , readonly)NSString *sn;
//软件版本查询
@property (nonatomic , copy , readonly)NSString *version;
//自动增益切换 （true: 开启 false:关闭）
@property (nonatomic)BOOL enableAutoGain;
//放灼烧检测开启 （true: 开启 false:关闭）
@property (nonatomic)BOOL enableFireProtect;
/// SDK 配置
/// @param configer 配置参数
+(void)setConfiger:(IFClientConfiger *)configer;
/// 增加回调监听
/// @param observer 监听对象
-(void)addParamObserver:(id<IFISPImageHandleInterface>)observer;
/// 移除回调监听
/// @param observer 监听对象
-(void)removeParamObserver:(id<IFISPImageHandleInterface>)observer;
@end

@interface IFClient (Camera)

/// 出图状态（true：出图中 false：停图）
@property (nonatomic , class , readonly)BOOL isStreaming;
/// 回话状态（true：回话创建成功 false：回话创建失败）
@property (nonatomic , class , readonly)BOOL isSessionOpened;
/// 设备连接状态（true：设备连接成功 false：设备连接失败）
@property (nonatomic , class , readonly)BOOL isDeviceConnect;

/// 出图
/// @param completion 出图结果回调 （succes true:操作成功 flase error 错误信息）
-(void)startStream:(void (^)(BOOL success , NSError *error))completion;

/// 出图 Ext
/// @param completion 出图结果回调 （succes true:操作成功 flase error 错误信息）
-(void)startStream:(void (^)(BOOL success , NSError *error))completion
          progress:(void(^)(BOOL needFlashRead , float progress))progress;

/// 停图
/// @param completion 停图结果回调 （succes true:操作成功 flase error 错误信息）
-(void)stopStream:(void (^)(BOOL success , NSError *error))completion;

/// 快门
/// @param completion 打快门操作（succes true:成功 flase:失败）
-(void)openShutter:(void(^)(BOOL success))completion;

/// 拍照
/// @param image 拍照图像数据（可从IFISPImageHandleInterface回调中获取image数据，此拍照接口对image增加温度数据后保存）
/// @param comletion 拍照结果回调（shotImageFilePath 保存的图片路径）
-(void)takeShotByImage:(UIImage *)image comletion:(void(^)(NSString *shotImageFilePath))comletion;

/// 增益切换
/// @param highGain (Yes: 高增益 No:低增益)
- (void)cameraSetGainMode:(BOOL)highGain
                         :(void (^)(BOOL success , NSError *error))completion;

/// 开启快门策略
- (void)startShutterPlan;

/// 关闭快门策略
- (void)stopShutterPlan;

@end

@interface IFClient (Pseudo)

/// 伪彩设置
@property (nonatomic) IFPseudoMode currentPseudoMode;

@end


typedef enum : NSUInteger {
    IFIRRotationTypeOriginal,
    IFIRRotationType90Degree,
    IFIRRotationType180Degree,
    IFIRRotationType270Degree
} IFIRRotationType;


@interface IFClient (Image)
/// 红外图像旋转
@property (nonatomic)IFIRRotationType irRotationType;
/// 红外图像镜像
@property (nonatomic) BOOL mirrorIR;
/// 亮度 （0-255 default: 128）
@property (nonatomic) int v_brightness;
/// 对比度 （0-255 default: 128）
@property (nonatomic) int v_contrast;
/// 目标距离（0.25-5 default: 0.25）
@property (nonatomic) float v_target_distance;
/// 环境温度（-10-55 default: 25.0）
@property (nonatomic) float v_environmental_temperature;
/// 发射率（0.01-1.0 default: 1.0）
@property (nonatomic) float v_emissivity;

@end

@interface IFTempMeasureResponse : NSObject
/// 温度最大值
@property (nonatomic , copy) NSNumber *maxTemp;
/// 温度最小值
@property (nonatomic , copy) NSNumber *minTemp;
/// 平均温度值 （如是点测温操作返回结果为点温度数据）
@property (nonatomic , copy) NSNumber *averageTemp;
/// 温度最大值坐标
@property (nonatomic) CGPoint maxCor;
/// 温度最小值坐标
@property (nonatomic) CGPoint minCor;
/// 温度最大值 （无修正）
@property (nonatomic , copy) NSNumber *org_maxTemp;
/// 温度最小值（无修正）
@property (nonatomic , copy) NSNumber *org_minTemp;
/// 平均温度值 （如是点测温操作返回结果为点温度数据）（无修正）
@property (nonatomic , copy) NSNumber *org_averageTemp;
@end

@interface IFClient (TemperatureMeasurement)
/// 点测温
/// @param imagePoint  测温点坐标
/// @param imageWidth  温度数据宽
/// @param imageHeight 温度数据高
/// @param imageBuffer 温度原始数据
-(IFTempMeasureResponse *)getPointTempWithImagePoint:(CGPoint)imagePoint
                                          imageWidth:(NSUInteger)imageWidth
                                         imageHeight:(NSUInteger)imageHeight
                                         imageBuffer:(uint8_t *)imageBuffer;

/// 线测温
/// @param startPoint 测温点开始坐标
/// @param endPoint 测温点开始坐标
/// @param imageWidth  温度数据宽
/// @param imageHeight 温度数据高
/// @param imageBuffer 温度原始数据
/// @return IFTempMeasureResponse 测温返回值
/// @see IFTempMeasureResponse
-(IFTempMeasureResponse *)getLineTempWithImageStartPoint:(CGPoint)startPoint
                                                endPoint:(CGPoint)endPoint
                                              imageWidth:(NSUInteger)imageWidth
                                             imageHeight:(NSUInteger)imageHeight
                                             imageBuffer:(uint8_t *)imageBuffer;

/// 框测温
/// @param startPoint 测温点开始坐标
/// @param endPoint 测温点开始坐标
/// @param imageWidth  温度数据宽
/// @param imageHeight 温度数据高
/// @param imageBuffer 温度原始数据
/// @return IFTempMeasureResponse 测温返回值
/// @see IFTempMeasureResponse
-(IFTempMeasureResponse *)getRectTempWithImageStartPoint:(CGPoint)startPoint
                                                endPoint:(CGPoint)endPoint
                                              imageWidth:(NSUInteger)imageWidth
                                             imageHeight:(NSUInteger)imageHeight
                                             imageBuffer:(uint8_t *)imageBuffer;

@end

@interface IFClient (Calibration)

/// 温度二次标定低温点设置
/// @param pointTemp 修正点温度（单位：摄氏度）
/// @param comletion 结果返回
-(void)secondCalibrationWithDoubleLowPoint:(float)pointTemp comletion:(void(^)(BOOL success , NSError *e))comletion;


/// 温度二次标定高温点设置
/// @param pointTemp 修正点温度（单位：摄氏度）
/// @param comletion 结果返回
-(void)secondCalibrationWithDoubleHighPointTemp:(float)pointTemp comletion:(void(^)(BOOL success , NSError *e))comletion;

/// 重置温度二次标定数据
/// @param comletion 结果返回
-(void)clearCalibrationDataWithCompletion:(void(^)(BOOL success , NSError *e))comletion;

/// 锅盖标定
/// @param comletion 结果返回
-(void)rmvcCalibration:(void(^)(BOOL success , NSError *e))comletion;

@end

@interface IFClient (Log)

//日志开启（默认关 YES: 开 NO: 关）
@property (nonatomic) BOOL enableLogcat;

@end

@interface IFClient (flash)

/// 温度二次标定高温点设置
/// @param data 写入数据（Byte写入）
/// @param error 写入错误信息
-(void)oemFlashWrite:(NSData *)data error:(NSError **)error;


/// 温度二次标定高温点设置
/// @param error  读取错误信息
/// @param length  读取数据的长度
/// @return NSData  返回的数据
-(NSData *)oemFlashRead:(NSError **)error length:(NSUInteger)length;

@end

@interface IFClient (Ext)

/// 放灼烧是否保护中
@property (nonatomic , readonly) BOOL isFireProtecting;

-(void)resetFireProjecting;

@end
