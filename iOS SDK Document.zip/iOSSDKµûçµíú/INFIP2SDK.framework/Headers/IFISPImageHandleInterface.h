//
//  IFISPImageHandleInterface.h
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/7/12.
//

#import <UIKit/UIKit.h>

@protocol IFISPImageHandleInterface <NSObject>

@optional

/// Camera连接
- (void)didReceiveConnectNotification;
/// Camer断开
- (void)didReceiveDisconnectNotification;
/// APP退到后台（同UIApplicationDidEnterBackgroundNotification）
- (void)didEnterBackgroundNotification;
/// APP回到前台（同UIApplicationWillEnterForegroundNotification）
- (void)didEnterForegroundNotification;

/// 图像数据采集
/// @param data 原始图像数据 NSData类型呢
- (void)didReceivedImageData:(NSData *)data;

/// 图像数据采集
/// @param image 处理后的图像数据 UIIimage类型
/// @param originalIRData 原始图像数据 NSData 类型
/// @param originalTempData 原始温度数据 NSData 类型
/// @param solvedIRData 处理后的图像数据 NSData 类型
/// @param solvedTempData 处理后的温度数据 NSData 类型
- (void)didReceivedSolvedImage:(UIImage *)image
                originalIRData:(NSData *)originalIRData
              originalTempData:(NSData *)originalTempData
                  solvedIRData:(NSData *)solvedIRData
                solvedTempData:(NSData *)solvedTempData;

///放灼烧触发
-(void)didFireProtectOpend;

@end
