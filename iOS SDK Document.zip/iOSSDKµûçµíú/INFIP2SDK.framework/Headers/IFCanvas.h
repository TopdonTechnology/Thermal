//
//  IFCanvas.h
//  IFUISDK
//
//  Created by zsc-onlyyi on 2022/3/11.
//

#import <Foundation/Foundation.h>
#import "IFDrawEnum.h"
#import "IFCanvasConfig.h"
#import "IFCanvasItemBase.h"
#import "IFCanvasView.h"

@interface IFCanvas<__contravariant T> : NSObject

@property (nonatomic , strong , readonly) IFCanvasView *canvasView;

@property (nonatomic , strong , readonly) NSMutableArray<T> *items;

@property (nonatomic , strong) IFCanvasItemDot *maxTempItemDot;
@property (nonatomic , strong) IFCanvasItemDot *minTempItemDot;
@property (nonatomic , strong) IFCanvasItemDot *centerTempItemDot;

@property (nonatomic , strong) IFCanvasItemDot *highlightTempItemDot;
@property (nonatomic , strong) IFCanvasItemDot *targetTempItemDot;

//add new control items count max limit 15 : default:simple=unsupported professional=3)
@property (nonatomic , strong) NSNumber *itemsCount;

@property (nonatomic , strong) void(^canvasChanged)(BOOL);
@property (nonatomic , strong) void(^didSelectItem)(IFCanvasItemBase *item);

@property IFDrawShapeType currentShapeType;

+(IFCanvas *)create;

-(IFCanvas *(^)(IFCanvasConfig *))setConfiger;

-(IFCanvas *(^)(IFDrawShapeType))switchShapeType;

-(IFCanvas *(^)(IFDrawType))switchDrawType;

-(IFCanvas *(^)(UIView *))addSuperview;

-(IFCanvasItemBase *)addShaper:(CGPoint)startPoint endPoint:(CGPoint)endPoint drawType:(IFDrawShapeType)shapeType;

-(void)clearAllViews;

@end
