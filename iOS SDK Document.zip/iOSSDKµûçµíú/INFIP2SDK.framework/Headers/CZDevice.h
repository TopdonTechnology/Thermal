//
//  CZDevice.h
//  IOS-P2
//
//  Created by zsc-onlyyi on 2022/4/1.
//

#import <UIKit/UIKit.h>

extern NSNotificationName const CZDeviceOrientationDidChangeNotification;

@interface CZDevice : UIDevice

@property (nonatomic , copy , class , readonly) NSString * bundleIdentifier;
@property (nonatomic , copy , class , readonly) NSString * appName;
@property (nonatomic , copy , class , readonly) NSString * appVersion;
@property (nonatomic , class , readonly) UIDeviceOrientation czOrientation;

+ (NSString *)deviceType;

+ (NSString *)deviceTypeName;

+ (void)enableRotation;

+ (void)rotateViewToButUpsidedownOrientation:(UIView *)view animated:(BOOL)animated;

+ (void)rotateViewToPortraitOrientation:(UIView *)view animated:(BOOL)animated;

+ (void)rotateViewToAllOrientation:(UIView *)view animated:(BOOL)animated;

+ (void)keepIdleTimerDisabled;

+ (void)keepIdleTimerEnabled;
@end

