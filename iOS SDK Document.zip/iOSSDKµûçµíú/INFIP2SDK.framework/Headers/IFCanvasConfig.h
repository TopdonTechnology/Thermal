//
//  IFCanvasConfig.h
//  IFUISDK
//
//  Created by zsc-onlyyi on 2022/3/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IFCanvasConfig : NSObject

@property (nonatomic) NSInteger contentWidth;///内容宽度
@property (nonatomic) NSInteger contentHeight;///内容高度
@property (nonatomic , strong) UIColor * borderColor;///边框颜色
@property (nonatomic) NSInteger borderWidth;///边框宽
@property (nonatomic, strong) UIColor *labelColor;///标签颜色
@property (nonatomic, strong) UIFont *labelFont;///标签字体
@property (nonatomic, strong) UIColor *minTempColor;///低温点颜色
@property (nonatomic, strong) UIColor *maxTempColor;///高温点颜色
@property (nonatomic) CGFloat tempPointRadius;///温度点半径
@property (nonatomic) NSInteger imageWidth;///图片宽度
@property (nonatomic) NSInteger imageHeight;///图片高度
@property (nonatomic) BOOL disableMeasureResultView;//客户自定义（不显示测温结果，客户自定义）
@property (nonatomic,strong) UIImage *dotIconImage;///测温点图片
@property (nonatomic) BOOL enableCustomTagName;//全局开启自定义标签
@end


NS_ASSUME_NONNULL_END
