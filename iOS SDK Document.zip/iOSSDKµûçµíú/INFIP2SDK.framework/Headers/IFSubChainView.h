//
//  IFSubChainView.h
//  IFUISDK
//
//  Created by zsc-onlyyi on 2022/4/25.
//

#import <UIKit/UIKit.h>

@interface IFSubChainView : UIImageView

//@property (nonatomic , strong) NSArray *enableViewClassNames;

@end
